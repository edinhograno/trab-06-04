function load() {    
    nome = document.getElementById("spanNome");
    endereco = document.getElementById("spanEndereco");
    cidade = document.getElementById("spanCidade");
    estado = document.getElementById("spanEstado");
    nomeDeUsuario = document.getElementById("spanNomeDeUsuario");
    senha = document.getElementById("spanSenha");

    nome.textContent = localStorage.getItem("nomecompleto");
    endereco.textContent = localStorage.getItem("endereco");
    cidade.textContent = localStorage.getItem("cidade");
    estado.textContent = localStorage.getItem("estado");
    nomeDeUsuario.textContent = localStorage.getItem("nomelogin");
    senha.textContent = localStorage.getItem("senha")    
}
load()