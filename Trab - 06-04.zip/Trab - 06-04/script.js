senha = document.getElementById('password');
confirmSenha = document.getElementById('confirmpassword');
botao = document.getElementById('botao');


function salvaTudo() {
    // ARMAZENAMENTO NOME COMPLETO
    localStorage.setItem("nomecompleto", document.querySelector("[name='nomecompleto']").value.toUpperCase());
    // ARMAZENAMENTO ENDEREÇO
    localStorage.setItem("endereco", document.querySelector("[name='endereco']").value.toUpperCase());
    // ARMAZENAMENTO CIDADE
    localStorage.setItem("cidade", document.querySelector("[name='cidade']").value.toUpperCase());
    // ARMAZENAMENTO ESTADO
    localStorage.setItem("estado", document.querySelector("[name='estado']").value.toUpperCase());
    // ARMAZENAMENTO NOME DO LOGIN
    localStorage.setItem("nomelogin", document.querySelector("[name='nomelogin']").value);
    // ARMAZENAMENTO SENHA
    localStorage.setItem("senha", document.querySelector("[name='senha']").value);
    // ARMAZENAMENTO CONFIRMAÇÃO DE SENHA
    localStorage.setItem("confsenha", document.querySelector("[name='confsenha']").value);
}

function validaTudo() {
    const minLength = 1;
    const nomeLength = document.querySelector("[name='nomecompleto']").value.length;
    const enderecoLength = document.querySelector("[name='endereco']").value.length;
    const cidadeLength = document.querySelector("[name='cidade']").value.length;
    const estadoLength = document.querySelector("[name='estado']").value.length;
    const nomeLoginLength = document.querySelector("[name='nomelogin']").value.length;

    if (nomeLength, enderecoLength, estadoLength >= 8 && cidadeLength, nomeLoginLength >= 2) {
        return true
    }else{
        window.alert('Preencha todos os campos obrigatórios! Min 8 caracteres e cidade / nome de usuário 2 caracteres!')
    }
    return false
}

function passwordIsValid() {
    const minLength = 8;
    const senhaLength = document.getElementById('password').value.length;

    if (senhaLength < minLength) {
        window.alert('Digite uma senha com no mínimo 8 caracteres!')
        return false
    }
    return true
}

botao.addEventListener('click', (e) => {
    e.preventDefault();

    if (!validaTudo()) return
    if (!passwordIsValid()) return
    

    if (senha.value == confirmSenha.value) {
        const usuarioConfirmou = window.confirm('Seus dados estão corretos?');
        if (usuarioConfirmou) {
            salvaTudo()
            window.location.href = "index2.html";
        } else {
            Text = "Corrija os campos!"
        }
    } else {
        window.alert('As senhas não correspondem!');
    }
})
